//
//  GuessBoardView.h
//  Drawus
//
//  Created by Tianhang Yu on 12-3-22.
//  Copyright (c) 2012年 99fang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@class DrawingModel;
@protocol GuessBoardViewDelegate;

@interface GuessBoardView : UIView

@property (nonatomic, retain) id<GuessBoardViewDelegate> drDelegate;
@property (nonatomic, retain) DrawingModel *drawing;

- (void)displayGuessMedia;

@end

@protocol GuessBoardViewDelegate <NSObject>

@optional
- (void)guessBoard:(GuessBoardView *)guessBoard didFinishPlaybackInMoviePlayer:(MPMoviePlayerController *)moviePlayer;

@end
