//
//  GuessBoardView.m
//  Drawus
//
//  Created by Tianhang Yu on 12-3-22.
//  Copyright (c) 2012年 99fang. All rights reserved.
//


#import "GuessBoardView.h"
#import "DrawPathModel.h"
#import "DrawingModel.h"

#define BACKGROUND_COLOR_STRING   @"#ffffff"


@interface GuessBoardView () {

    MPMoviePlayerController *_moviePlayer;
}

@end

@implementation GuessBoardView

@synthesize drDelegate=_drDelegate;
@synthesize drawing=_drawing;

#pragma mark - private

- (void)playbackDidFinish:(NSNotification *)notification
{
    if (_drDelegate != nil) {
        if ([_drDelegate respondsToSelector:@selector(guessBoard:didFinishPlaybackInMoviePlayer:)]) {
            [_drDelegate guessBoard:self didFinishPlaybackInMoviePlayer:_moviePlayer];
        }
    }
}

#pragma mark - public

- (void)setDrawing:(DrawingModel *)drawing
{
    [_drawing release];
    _drawing = [drawing retain];

    self.backgroundColor = [UIColor colorWithHexString:BACKGROUND_COLOR_STRING];
    
    NSString *moviePath = [[NSBundle mainBundle] pathForResource:@"kimi" ofType:@"mp4"];
    if (moviePath) 
    {
        NSURL *movieURL = [NSURL fileURLWithPath:moviePath];
        _moviePlayer = [[MPMoviePlayerController alloc] initWithContentURL:movieURL];
    }
    
    _moviePlayer.controlStyle = MPMovieControlStyleNone;
    _moviePlayer.view.userInteractionEnabled = NO;
    _moviePlayer.shouldAutoplay = NO;
    [_moviePlayer.view setFrame:self.bounds];
    [self addSubview:_moviePlayer.view];
}

- (void)displayGuessMedia
{
    [_moviePlayer play];
}

#pragma mark - default

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [[NSNotificationCenter defaultCenter] addObserver:self 
                                                 selector:@selector(playbackDidFinish:) 
                                                     name:MPMoviePlayerPlaybackDidFinishNotification 
                                                   object:nil];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    
    [_moviePlayer release];
    _moviePlayer = nil;

    self.drawing = nil;

	[super dealloc];
}

@end
